package com.gymgroup.service;

import com.gymgroup.entities.Tags;

import java.util.List;

public interface TagsService {

    List<Tags> findAll();
}
