package com.gymgroup.dao;

import com.gymgroup.entities.Brand;

import java.util.List;

public interface BrandDao  {


    List<Brand> findAll();
}
