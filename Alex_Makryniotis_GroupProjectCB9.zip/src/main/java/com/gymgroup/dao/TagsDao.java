package com.gymgroup.dao;

import com.gymgroup.entities.Tags;

import java.util.List;

public interface TagsDao {

    List<Tags> findAll();
}
