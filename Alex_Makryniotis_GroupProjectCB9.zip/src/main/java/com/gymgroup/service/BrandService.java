package com.gymgroup.service;

import com.gymgroup.entities.Brand;

import java.util.List;

public interface BrandService {

    List<Brand> findAll();
}
