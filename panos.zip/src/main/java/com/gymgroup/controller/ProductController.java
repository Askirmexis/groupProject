package com.gymgroup.controller;

import com.gymgroup.entities.Product;
import com.gymgroup.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.ws.rs.PathParam;

@Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired
    ProductService productService;

    @GetMapping()
    public String viewProduct() {
        return "allproducts";
    }

    @GetMapping("/treadmill")
    public String viewTreadmill() {
        return "treadmills";
    }

    @GetMapping("/elliptical")
    public String viewElliptical() {
        return "elliptical";
    }

    @GetMapping("/bike")
    public String viewBike() {
        return "bikes";
    }

    @GetMapping("/rower")
    public String viewRowers() {
        return "rower";
    }

    @GetMapping("/bench")
    public String viewBench() {
        return "bench";
    }

    @GetMapping("/weight-Bar")
    public String viewWeightBars() {
        return "weight-bars";
    }

    @GetMapping("/kettlebell")
    public String viewKettleBell() {
        return "kettlebell";
    }

    @GetMapping("/dumbbell")
    public String viewDumbell() {
        return "dumbbell";
    }

    @GetMapping("/multigym")
    public String viewMultigyms() {
        return "multigyms";
    }

    @GetMapping("/tol")
    public String viewTools() {
        return "tools";
    }

    @GetMapping("/brands")
    public String testingStuff() {
        return "brandFilters";
    }

    @GetMapping("/{id}")
    public String getSingleProduct(@PathVariable("id") int id, Model model) {
        Product p = productService.findProductById(id);
        model.addAttribute("productId", p.getProductId());
        return "productDetails";
    }

    //    @GetMapping("/{title}")
//    public String testMapping(@PathVariable("title") String title) {
//        return "test";
//    }
    @GetMapping("/cardio")
    public String getCardio() {
        return "cardio";
    }
//

    @GetMapping("/strength")
    public String getStrength() {
        return "strength";
    }

    @GetMapping("/functionality")
    public String getFunctionality() {
        return "functionality";
    }
}
